const mongoose = require("mongoose");

const connectDB = async () => {
    try {
        // Try MongoDB Atlas first
        const mongoURI =
            process.env.MONGODB_URI ||
            "mongodb+srv://mani001:admin@cluster0.tzie1yt.mongodb.net/crm_db?retryWrites=true&w=majority";

        const conn = await mongoose.connect(mongoURI, {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });

        console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
        return true;
    } catch (atlasError) {
        console.warn(
            `⚠️  MongoDB Atlas connection failed: ${atlasError.message}`,
        );

        // Fallback to local MongoDB
        try {
            console.log("Attempting to connect to local MongoDB...");
            // Using the same URI as fallback seems wrong based on the logs, but I will just fix the options for now. 
            // The user's code had the same URI for both. I will keep it as is but fix options.
            const conn = await mongoose.connect(
                "mongodb+srv://mani001:admin@cluster0.tzie1yt.mongodb.net/crm_db?retryWrites=true&w=majority",
                {
                    serverSelectionTimeoutMS: 5000,
                },
            );
            console.log(`✅ Local MongoDB Connected: ${conn.connection.host}`);
            return true;
        } catch (localError) {
            console.error(`❌ Both MongoDB Atlas and Local MongoDB failed`);
            console.error(`Atlas Error: ${atlasError.message}`);
            console.error(`Local Error: ${localError.message}`);
            console.log("\n⚠️  Running without database connection. Please:");
            console.log("   1. Start local MongoDB: mongodb");
            console.log("   2. Or check MongoDB Atlas credentials");
            console.log("   3. Or set MONGODB_URI environment variable");
            return false;
        }
    }
};

module.exports = connectDB;
